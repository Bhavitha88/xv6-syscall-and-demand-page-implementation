#include "user/user.h"
#include "kernel/syscall.h"

int main() {
    getYear(); 
    exit(0);
}

