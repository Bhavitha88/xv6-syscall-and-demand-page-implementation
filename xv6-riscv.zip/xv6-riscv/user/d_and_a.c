#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define PGSIZE 4096

int main(int argc, char *argv[])
{
    if (argc != 4) {
        printf("Usage: %s <start_va> <num_pages> <buf_addr>\n", argv[0]);
        exit(1);
    }

    // Parse arguments
    int local[5];
    local[0]= 5; //initialize with any integer value
    printf ("User address apace: %x\n", glob);
	for (int i=1;i<5;i++){
		local[i]=6;
	}
     int num_pages = 6;
   // uint64 buf_addr = atoi(argv[3]);
    uint64 start_va = (uint64)local;
    uint64 buf_addr[num_pages];
    //uint64 start_va = atoi(argv[1]);
   

    if (num_pages <= 0) {
        printf("Invalid number of pages\n");
        exit(1);
    }

    // Call pgaccess system call
    if (pgaccess(start_va, num_pages, buf_addr) < 0) {
        printf("Error: pgaccess system call failed\n");
        exit(1);
    }


    // Print results
    for (int i = 0; i < num_pages; i++) {
        int access_bit = result_buffer[i] & 1;
        int dirty_bit = (result_buffer[i] >> 1) & 1;
        printf("Page %d: Accessed: %d, Dirty: %d\n", i, access_bit, dirty_bit);
    }

    free(result_buffer);
    exit(0);
}

