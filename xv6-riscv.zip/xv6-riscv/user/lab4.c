#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"

#define MAX_BUF_SIZE 512

int main(int argc, char *argv[]) {
    // Check if correct number of arguments provided
    if (argc != 4) {
        fprintf(1, "Usage: createfile <fileName> <fileSize> <rollNo>\n");
        exit(0);
    }

    // Extracting fileName, fileSize, and rollNo from arguments
    char *fileName = argv[1];
    int fileSize = atoi(argv[2]);
    char *rollNo = argv[3];

    // Opening the file
    int fd = open(fileName, O_CREATE | O_RDWR);
    if (fd < 0) {
        printf("Error: Unable to open or create file\n");
        exit(0);
    }

    //Here I am allocating disk block and writing roll no.
    
    char buffer[MAX_BUF_SIZE];
    for (int i = 0; i < fileSize; i += MAX_BUF_SIZE) {
        memset(buffer, '\0', MAX_BUF_SIZE);
        // Write rollNo to buffer
        strcpy(buffer, rollNo);
        // Write the buffer to file
        write(fd, buffer, MAX_BUF_SIZE);
    }

    // Close the file
    close(fd);

    // Re-open the file to get inode number and print block numbers and contents
    fd = open(fileName, O_RDWR);
    if (fd < 0) {
        printf("Error: Unable to reopen file\n");
        exit(0);
    }

    // Get inode number
    struct stat st;
    if (fstat(fd, &st) < 0) {
        printf("Error: Unable to get file information\n");
        exit(0);
    }
    fprintf(1, "Inode number: %d\n", st.ino);

    // Print block numbers and contents present in the block number
    for (int i = 0; i < fileSize; i += MAX_BUF_SIZE) {
        fprintf(1, "Block number: %d\n", i / MAX_BUF_SIZE);
        memset(buffer, '\0', MAX_BUF_SIZE);
        // Read block contents
        read(fd, buffer, MAX_BUF_SIZE);
        // Print block contents
        fprintf(1, "Block contents: ");
        for (int j = 0; j < MAX_BUF_SIZE; j++) {
        if (buffer[j] == '\0') {
           break;
        }
        fprintf(1, "%c", buffer[j]);
    }
    fprintf(1, "\n");
    }

    // Closing the file
    close(fd);

    exit(0);
}
