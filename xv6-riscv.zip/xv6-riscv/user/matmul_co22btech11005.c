#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"

#define MAX_BUF_SIZE 512

int main(int argc, char *argv[]) {
    // Check if correct number of arguments provided
    if (argc != 5) {
        fprintf(1, "Usage: createfile <fileName> <fileSize> <rollNo>\n");
        exit(0);
    }

    // Extracting fileName, fileSize, and rollNo from arguments
    
    int sizeA1 = atoi(argv[1]);
    int sizeA2 = atoi(argv[2]);
    int sizeB1 = atoi(argv[3]);
    int sizeB2 = atoi(argv[4]);
    
   int (*A)[sizeA1][sizeA2];
   int (*B)[sizeB1][sizeB2];
   int (*C)[sizeA1][sizeB2];
   for(int i = 0; i < sizeA1; i++){
     for(int j = 0; j < sizeA2;j++){
       (*A)[i][j] = rand()%100;
     }
   }
   
   for(int i = 0; i < sizeB1; i++){
     for(int j = 0; j < sizeB2;j++){
       (*B)[i][j] = rand()%100;
     }
   }
    int fd = open("matA.txt", O_CREATE | O_RDWR);
    if (fd < 0) {
        printf("Error: Unable to open or create file\n");
        exit(0);
    }
    for(int i = 0; i < sizeA1; i++){
     for(int j = 0; j < sizeA2;j++){
       fprintf(fd,"%d ",(*A[i][j]));
     }
     fprintf(fd,"\n");
   }
   
   int fd1 = open("matB.txt", O_CREATE | O_RDWR);
    if (fd1 < 0) {
        printf("Error: Unable to open or create file\n");
        exit(0);
    }
   for(int i = 0; i < sizeB1; i++){
     for(int j = 0; j < sizeB2;j++){
       fprintf(fd1,"%d ",(*B[i][j]));
     }
     fprintf(fd1,"\n");
   }
   
   for (int k = 0; k < sizeA1; k++) {
        for (int p = 0; p < sizeA2; p++) {
            int sum = 0;
            for (int q = 0; q < sizeB2; q++) {
                sum += (*A)[k][q] * (*B)[q][p];
            }
            (*C)[k][p] = sum;
        }
    }
   int fd2 = open("matC.txt", O_CREATE | O_RDWR);
    if (fd2 < 0) {
        printf("Error: Unable to open or create file\n");
        exit(0);
    }
   for(int i = 0; i < sizeA1; i++){
     for(int j = 0; j < sizeB2;j++){
       fprintf(fd2,"%d ",(*B[i][j]));
     }
     fprintf(fd2,"\n");
   }
   return 0;
}
