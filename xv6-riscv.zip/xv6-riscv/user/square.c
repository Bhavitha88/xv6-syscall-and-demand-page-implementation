#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

int main(){
   printf("Square of 7 is %d\n",square(7));
   exit(0);

}
