#include <kernel/syscall.h>
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#define N 10000


int main(void) {
    int a[N]; 
    a[2] = 10;
    printf("Value of a: %d\n", a[2]);
    pgtPrint();
    exit(0);
}
