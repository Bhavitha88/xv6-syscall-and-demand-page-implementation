#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define PGSIZE 4096

int main(int argc, char *argv[])
{
    if (argc != 4) {
        printf("Usage: %s <start_va> <num_pages> <buf_addr>\n", argv[0]);
        exit(1);
    }

    // Parse arguments
    local[0]= 5; //initialize with any integer value
    printf ("User address apace: %x\n", glob);
	for (int i=1;i<5;i++){
		local[i]=local[i-1];
	}
     int num_pages = 6;
   // uint64 buf_addr = atoi(argv[3]);
    uint64 start_va = (uint64)local;
    uint64 buf_addr[num_pages];
    //uint64 start_va = atoi(argv[1]);
   

    if (num_pages <= 0) {
        printf("Invalid number of pages\n");
        exit(1);
    }

    // Call pgaccess system call
    if (pgaccess(start_va, num_pages, buf_addr) < 0) {
        printf("Error: pgaccess system call failed\n");
        exit(1);
    }

    // Read results from user space buffer
    uint8 *result_buffer = (uint8 *)malloc(num_pages);
    if (read(buf_addr, result_buffer, num_pages) < 0) {
        printf("Error: Failed to read results from buffer\n");
        free(result_buffer);
        exit(1);
    }

    // Print results
    for (int i = 0; i < num_pages; i++) {
        uint8 access_bit = result_buffer[i] & 0x01;
        uint8 dirty_bit = (result_buffer[i] >> 1) & 0x01;
        printf("Page %d: Accessed: %d, Dirty: %d\n", i, access_bit, dirty_bit);
    }

    free(result_buffer);
    exit(0);
}

